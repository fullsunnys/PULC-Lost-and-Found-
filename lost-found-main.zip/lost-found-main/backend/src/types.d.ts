declare module 'xss';
